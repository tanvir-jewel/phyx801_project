`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 04/30/2025 01:55:18 PM
// Design Name: 
// Module Name: uart_tx
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
module uart_tx #(
  parameter int CLOCK_FREQ = 100_000_000,  // 100 MHz
  parameter int BAUD_RATE  = 115_200       // 115200 baud
)(
  input  wire       clk,
  input  wire       rst,
  input  wire [7:0] data_in,
  input  wire       data_valid,
  output reg        busy,
  output reg        tx
);

  // How many clock ticks per bit period
  localparam int CLKS_PER_BIT = CLOCK_FREQ / BAUD_RATE;
  localparam int CNT_WIDTH    = $clog2(CLKS_PER_BIT);

  // State machine
  typedef enum logic { IDLE, TRANSMIT } state_t;
  state_t state, next_state;

  reg [CNT_WIDTH-1:0] clk_count;
  reg [3:0]          bit_index;
  reg [9:0]          shift_reg;  // {stop, data[7:0], start}

  // Sequential: clock divider, shift, tx output
  always_ff @(posedge clk or posedge rst) begin
    if (rst) begin
      state     <= IDLE;
      clk_count <= 0;
      bit_index <= 0;
      shift_reg <= 10'h3FF;  // idle = all 1s
      tx        <= 1'b1;     // line idle high
      busy      <= 1'b0;
    end else begin
      state <= next_state;
      case (state)
        IDLE: begin
          tx        <= 1'b1;
          clk_count <= 0;
          bit_index <= 0;
          busy      <= 1'b0;
          if (data_valid) begin
            busy      <= 1'b1;
            // Frame = {stop bit, 8 data bits, start bit}
            shift_reg <= {1'b1, data_in, 1'b0};
          end
        end

        TRANSMIT: begin
          tx <= shift_reg[0];  // send LSB first (start / data / stop)
          if (clk_count < CLKS_PER_BIT-1) begin
            clk_count <= clk_count + 1;
          end else begin
            clk_count <= 0;
            shift_reg <= {1'b1, shift_reg[9:1]}; // shift right, fill 1 for stop
            if (bit_index == 9) begin
              bit_index <= 0;
              busy      <= 1'b0;
            end else begin
              bit_index <= bit_index + 1;
            end
          end
        end
      endcase
    end
  end

  // Next-state logic
  always_comb begin
    next_state = state;
    case (state)
      IDLE:
        if (data_valid) next_state = TRANSMIT;
      TRANSMIT:
        if (!busy) next_state = IDLE;
    endcase
  end

endmodule

