`timescale 1ns/1ps

module qft_uart_top #(
  parameter int NUM_BIT         = 5,               // log2(NUM_SAMPLE)
  parameter int COMPLEXNUM_BIT  = 24,              // width of fixed-point
  parameter int FP_BIT          = 22,              // fractional bits
  parameter int CLOCK_FREQ      = 100_000_000,
  parameter int BAUD_RATE       = 115_200
)(
  input  logic                    clk,
  input  logic                    rst,
  input  logic                    start,
  output logic                    tx,
  output logic                    done
);

  // Derived parameters
  localparam int NUM_SAMPLE    = 1 << NUM_BIT;
  localparam int QFT_LATENCY   = 4 * NUM_SAMPLE * NUM_BIT;  // pipelined butterfly latency
  localparam int BYTE_PER_WORD = (COMPLEXNUM_BIT + 7)/8;    // = 3

  //-------------------------------------------------------------------------
  // DUT instance
  //-------------------------------------------------------------------------
  logic signed [COMPLEXNUM_BIT-1:0] in_r  [0:NUM_SAMPLE-1];
  logic signed [COMPLEXNUM_BIT-1:0] in_i  [0:NUM_SAMPLE-1];
  wire   signed [COMPLEXNUM_BIT-1:0] out_r [0:NUM_SAMPLE-1];
  wire   signed [COMPLEXNUM_BIT-1:0] out_i [0:NUM_SAMPLE-1];

  qft5_emulate #(
    .sample_size    (NUM_SAMPLE),
    .complexnum_bit (COMPLEXNUM_BIT),
    .fp_bit         (FP_BIT),
    .mul_h          (25'h2D413C)
  ) u_qft (
    .clk   (clk),
    .rst   (rst),
    .in_r  (in_r),
    .in_i  (in_i),
    .out_r (out_r),
    .out_i (out_i)
  );

  //-------------------------------------------------------------------------
  // Capture registers
  //-------------------------------------------------------------------------
  logic signed [COMPLEXNUM_BIT-1:0] cap_r [0:NUM_SAMPLE-1];
  logic signed [COMPLEXNUM_BIT-1:0] cap_i [0:NUM_SAMPLE-1];

  //-------------------------------------------------------------------------
  // UART TX
  //-------------------------------------------------------------------------
  logic        tx_busy, tx_valid;
  logic [7:0]  tx_byte;
  uart_tx #(
    .CLOCK_FREQ (CLOCK_FREQ),
    .BAUD_RATE  (BAUD_RATE)
  ) u_uart (
    .clk        (clk),
    .rst        (rst),
    .data_in    (tx_byte),
    .data_valid (tx_valid),
    .busy       (tx_busy),
    .tx         (tx)
  );

  //-------------------------------------------------------------------------
  // Top-level FSM / counters
  //-------------------------------------------------------------------------
  typedef enum logic [2:0] { S_IDLE, S_APPLY, S_WAIT, S_CAPTURE, S_SEND, S_DONE } state_t;
  state_t  ps, ns;
  int      cycle_cnt;
  int      sample_idx;
  int      byte_idx;

  always_ff @(posedge clk or posedge rst) begin
    if (rst) begin
      ps         <= S_IDLE;
      cycle_cnt  <= 0;
      sample_idx <= 0;
      byte_idx   <= 0;
      done       <= 0;
    end else begin
      ps <= ns;
      case (ps)
        S_IDLE: begin
          done <= 0;
        end

        S_APPLY: begin
          // apply delta vector
          for (int i = 0; i < NUM_SAMPLE; i++) begin
            in_r[i] <= (i == 0) ? $signed(1 << FP_BIT) : '0;
            in_i[i] <= '0;
          end
          cycle_cnt <= 0;
        end

        S_WAIT: begin
          cycle_cnt <= cycle_cnt + 1;
        end

        S_CAPTURE: begin
          for (int i = 0; i < NUM_SAMPLE; i++) begin
            cap_r[i] <= out_r[i];
            cap_i[i] <= out_i[i];
          end
          sample_idx <= 0;
          byte_idx   <= 0;
        end

        S_SEND: begin
          // advance only when UART accepted
          if (tx_valid && !tx_busy) begin
            if (byte_idx + 1 == 2*BYTE_PER_WORD) begin
              byte_idx   <= 0;
              sample_idx <= sample_idx + 1;
            end else begin
              byte_idx <= byte_idx + 1;
            end
          end
        end

        S_DONE: begin
          done <= 1;
        end
      endcase
    end
  end

  // Next-state logic
  always_comb begin
    ns = ps;
    case (ps)
      S_IDLE:    if (start)                    ns = S_APPLY;
      S_APPLY:   ns = S_WAIT;
      S_WAIT:    if (cycle_cnt >= QFT_LATENCY) ns = S_CAPTURE;
      S_CAPTURE: ns = S_SEND;
      S_SEND:    if (sample_idx >= NUM_SAMPLE) ns = S_DONE;
      default:   ;
    endcase
  end

  //-------------------------------------------------------------------------
  // Byte extraction logic
  //-------------------------------------------------------------------------
  logic signed [COMPLEXNUM_BIT-1:0] selected_word;
  logic [31:0]                     offset_full;
  logic [1:0]                      byte_offset;

  always_comb begin
    tx_valid = 1'b0;
    tx_byte  = 8'h00;

    if (ps == S_SEND && !tx_busy && sample_idx < NUM_SAMPLE) begin
      // choose real or imag
      if (byte_idx < BYTE_PER_WORD)
        selected_word = cap_r[sample_idx];
      else
        selected_word = cap_i[sample_idx];

      // compute offset_full, then byte_offset
      offset_full = (byte_idx < BYTE_PER_WORD) ? byte_idx : byte_idx - BYTE_PER_WORD;
      byte_offset = offset_full[1:0];

      // extract MSB-first 8-bit chunk
      case (byte_offset)
        2'd0: tx_byte = selected_word[COMPLEXNUM_BIT-1  -: 8];
        2'd1: tx_byte = selected_word[COMPLEXNUM_BIT-9  -: 8];
        2'd2: tx_byte = selected_word[COMPLEXNUM_BIT-17 -: 8];
        default: tx_byte = 8'h00;
      endcase

      tx_valid = 1'b1;
    end
  end

endmodule
