`timescale 1ns/1ps

module tb_qft5_emulate;
  // Parameter definitions matching the DUT
  localparam int sample_size    = 32;
  localparam int complexnum_bit = 24;
  localparam int fp_bit         = 22;
  localparam logic [24:0] mul_h = 25'h2D413C;
    real real_part, imag_part;

  // Testbench signals
  reg                         clk;
  reg                         rst;
  reg  signed [complexnum_bit-1:0] in_r [0:sample_size-1];
  reg  signed [complexnum_bit-1:0] in_i [0:sample_size-1];
  wire signed [complexnum_bit-1:0] out_r [0:sample_size-1];
  wire signed [complexnum_bit-1:0] out_i [0:sample_size-1];

  // Instantiate the design under test (DUT)
  qft5_emulate #(
    .sample_size(sample_size),
    .complexnum_bit(complexnum_bit),
    .fp_bit(fp_bit),
    .mul_h(mul_h)
  ) dut (
    .clk(clk),
    .rst(rst),
    .in_r(in_r),
    .in_i(in_i),
    .out_r(out_r),
    .out_i(out_i)
  );

  // Clock generation: 100 MHz
  initial clk = 0;
  always #5 clk = ~clk;

  initial begin
    // Apply reset
    rst = 1;
    // Initialize inputs to zero
    for (int i = 0; i < sample_size; i++) begin
      in_r[i] = '0;
      in_i[i] = '0;
    end
    #20 rst = 0;

    // Stimulus 1: One-hot input at index 0 (value = 1.0 in fixed-point)
    in_r[0] = 1 << fp_bit;
    in_i[0] = 0;

    // Wait for outputs to settle
    #200;

    // Display results
    $display("QFT5 Emulate Testbench Results:");
  for (int i = 0; i < sample_size; i++) begin
    real_part = $itor(out_r[i]) / (1 << fp_bit);
    imag_part = $itor(out_i[i]) / (1 << fp_bit);
    $display(" out[%2d] = %f  + j%f", i, real_part, imag_part);
  end

    $finish;
  end
endmodule
