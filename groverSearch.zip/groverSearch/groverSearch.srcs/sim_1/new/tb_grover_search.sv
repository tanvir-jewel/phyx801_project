`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 04/29/2025 07:54:32 PM
// Design Name: 
// Module Name: tb_grover_search
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// tb_grover_search.sv
`timescale 1ns/1ps
module tb_grover_search;

   // --- Tunable problem size (keep tiny for a fast run) -------------
   localparam int NUM_BIT         = 4;           // N = 16 states
   localparam int FIXEDPOINT_BIT  = 24;
   localparam int NUM_SAMPLE      = 1 << NUM_BIT;

   // --- DUT I/O ------------------------------------------------------
   logic                                  clk;
   logic                                  rst;
   logic                                  start;
   logic [NUM_BIT-1:0]                    target_search;
   logic signed [FIXEDPOINT_BIT-1:0]      output_r [0:NUM_SAMPLE-1];
   logic                                  done;

   // --- Instantiate the design under test ---------------------------
   grover_search #(
       .num_bit        (NUM_BIT),
       .fixedpoint_bit (FIXEDPOINT_BIT)
   ) dut (
       .clk            (clk),
       .rst            (rst),
       .start          (start),
       .target_search  (target_search),
       .output_r       (output_r),
       .done           (done)
   );

   //------------------------------------------------------------------
   //  Clock generator : 100 MHz
   //------------------------------------------------------------------
   initial   clk = 0;
   always  #5 clk = ~clk;   // 10 ns period

   //------------------------------------------------------------------
   //  Stimulus
   //------------------------------------------------------------------
   initial begin
      // Power-on reset
      rst           = 1;
      start         = 0;
      target_search = 4'd3;        // Mark |3? as "solution"
      #50;
      rst   = 0;                   // release reset
      #20;

      // Kick off Grover search
      start = 1;
      #10   start = 0;

      // Wait for DUT to finish
      wait (done);

      $display("\nGrover finished at %0t\n", $time);
      // Dump amplitude vector
    for (int i = 0; i < NUM_SAMPLE; i++) begin
       real amp = output_r[i] / 4194304.0;
       $display("state %0d  amp=%0f  prob=%0f",
                i, amp, amp*amp);
    end
    
      #20;
      $stop;
   end
endmodule
