/*
 * grover_uart_wrapper.sv  -  resolves Synth 8-523
 * ---------------------------------------------------------------------------
 * Avoids invalid part-select when NUM_BIT ? 8 by wrapping the MSB extraction
 * in a generate-if block.  The MSB byte is wired to 0x00 otherwise.
 * ---------------------------------------------------------------------------
 */

`timescale 1ns/1ps

// ?????????????????????????????????????????????????????????????????????????????
// UART transmitter: 8-N-1
// ?????????????????????????????????????????????????????????????????????????????
module uart_tx #(
    parameter int CLOCK_FREQ = 100_000_000,
    parameter int BAUD_RATE  = 115_200
)(
    input  logic       clk,
    input  logic       rst,
    input  logic [7:0] data_in,
    input  logic       data_valid,
    output logic       busy,
    output logic       tx
);
    localparam int DIV = CLOCK_FREQ / BAUD_RATE;
    typedef enum logic [1:0] {IDLE, START, DATA, STOP} st_t; st_t st;
    logic [$clog2(DIV)-1:0] bc; logic [3:0] bi; logic [7:0] sh;
    assign tx   = (st==IDLE||st==STOP)?1'b1:(st==START)?1'b0:sh[0];
    assign busy = (st!=IDLE);
    always_ff @(posedge clk or posedge rst) if (rst) begin
        st<=IDLE; bc<=0; bi<=0; sh<=0;
    end else case(st)
        IDLE:  if (data_valid) begin sh<=data_in; st<=START; bc<=0; end
        START,DATA,STOP: if (bc==DIV-1) begin bc<=0;
            case(st)
              START: st<=DATA;
              DATA:  begin sh<={1'b0,sh[7:1]}; if(bi==7) begin bi<=0; st<=STOP; end else bi<=bi+1; end
              STOP:  st<=IDLE;
            endcase
        end else bc<=bc+1;
    endcase
endmodule

// ?????????????????????????????????????????????????????????????????????????????
// Wrapper: Grover core + UART streamer
// ?????????????????????????????????????????????????????????????????????????????
module grover_uart_top #(
    parameter int NUM_BIT        = 5,
    parameter int FIXEDPOINT_BIT = 24,
    parameter int CLOCK_FREQ     = 100_000_000,
    parameter int BAUD_RATE      = 115_200
)(
    input  logic               clk,
    input  logic               rst,
    input  logic               start,
    input  logic [NUM_BIT-1:0] target_search,
    output logic               tx,
    output logic               done
);
    localparam int NUM_SAMPLE = 1 << NUM_BIT;

    // Grover core -----------------------------------------------------------
    logic                                    core_done;
    logic signed [FIXEDPOINT_BIT-1:0]        amp_vec [NUM_SAMPLE];
    grover_search #(.num_bit(NUM_BIT), .fixedpoint_bit(FIXEDPOINT_BIT)) u_core (
        .clk(clk), .rst(rst), .start(start), .target_search(target_search),
        .output_r(amp_vec), .done(core_done)
    );
    assign done = core_done;

    // Compute winning index --------------------------------------------------
    logic [NUM_BIT-1:0] solution_idx;
    always_comb begin
        int unsigned max_i = 0;
        for (int unsigned i = 1; i < NUM_SAMPLE; i++)
            if ($signed(amp_vec[i]) > $signed(amp_vec[max_i])) max_i = i;
        solution_idx = max_i;
    end

    // Byte 0: always exists (zero-extended if NUM_BIT<8) ---------------------
    wire [7:0] sol_byte0 = (NUM_BIT >= 8) ? solution_idx[7:0] :
                           {{(8-NUM_BIT){1'b0}}, solution_idx};

    // Byte 1: generate only when NUM_BIT > 8 --------------------------------
    wire [7:0] sol_byte1;
    generate
        if (NUM_BIT > 8) begin : g_msb
            assign sol_byte1 = solution_idx[NUM_BIT-1:8];
        end else begin : g_msb
            assign sol_byte1 = 8'h00;
        end
    endgenerate
    localparam bit SEND_MSB = (NUM_BIT > 8);

    // Packet builder FSM -----------------------------------------------------
    typedef enum logic [1:0] {S_IDLE, S_SYNC, S_LSB, S_MSB} ps_t; ps_t ps,nps;
    logic tx_busy, tx_valid; logic [7:0] tx_byte;
    always_comb begin
        tx_valid=0; tx_byte=0; nps=ps;
        case(ps)
            S_IDLE: if(core_done&&!tx_busy) begin tx_valid=1; tx_byte=8'h55; nps=S_SYNC; end
            S_SYNC: if(!tx_busy) begin tx_valid=1; tx_byte=sol_byte0; nps=SEND_MSB?S_LSB:S_IDLE; end
            S_LSB:  if(!tx_busy&&SEND_MSB) begin tx_valid=1; tx_byte=sol_byte1; nps=S_IDLE; end
        endcase
    end
    always_ff @(posedge clk or posedge rst) if(rst) ps<=S_IDLE; else ps<=nps;

    // UART instance ----------------------------------------------------------
    uart_tx #(.CLOCK_FREQ(CLOCK_FREQ), .BAUD_RATE(BAUD_RATE)) u_tx (
        .clk(clk), .rst(rst), .data_in(tx_byte), .data_valid(tx_valid),
        .busy(tx_busy), .tx(tx)
    );
endmodule
